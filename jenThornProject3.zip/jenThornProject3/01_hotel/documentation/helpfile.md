Fonts:

Playfair Display https://www.google.com/fonts/specimen/Playfair+Display
Karla http://www.google.com/fonts/specimen/Karla

Fontawesome Icons:

Calendar: fa-calendar-o
Search: fa-search
Facebook fa-facebook
Twitter: fa-twitter
Linkedin: fa-linkedin
Google+: fa-google-plus
